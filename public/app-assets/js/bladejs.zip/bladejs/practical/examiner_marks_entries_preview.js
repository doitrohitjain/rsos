// <script type="text/javascript">
	// jQuery Form Validator
	
	$(document).ready(function() { 
		// "we will code if we need";
	}); 




