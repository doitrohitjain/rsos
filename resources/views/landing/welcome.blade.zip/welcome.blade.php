@extends('layouts.guest')
@section('content')
<div id="cards-extended">
	<div class="card">
		<div class="card-content">
	 <center>
		<span style="color:#00bcd4;font-size:20px;padding-top:20px;">
			<img src="{{asset('public/app-assets/images/favicon/administrator.png')}}" alt="materialize logo" width="40px" height="35px"/> 
		</span>
		<span style="color:#00bcd4;font-size:20px;padding-top:0px;">
			@php echo Config::get('global.siteTitle'); @endphp
		</span>
	</center>

 
      	<h4 class="card-title">
			<span> सामान्य निर्देश (General Instructions) </span>
			<span style="float:right;">
				@php 
					$SSO_URL_DASHBOARD = Config::get('global.SSO_URL_DASHBOARD'); 
				@endphp
				<a href="{{ @$SSO_URL_DASHBOARD }}" class="waves-effect waves-teal btn gradient-90deg-deep-orange-orange white-text secondary-content">
					Go To SSO
				</a>
			</span>
		</h4>
      	<p> 
			<span class="red-text">
				<b>
					Note: This application is best viewed using current versions of Firefox, Chrome at a screen resolution of 1024 x 768 or higher.This application will not work in Internet explorer Ver 11 and above.
				</b>
			</span>
		<?php  
			$lists = array();
			
			$lists[] = array('lbl_text' => 'प्रवेश शुल्क ऑनलाइन भुगतान के लिए बटन पर क्लिक करें(Click on the button for Admission Fee Online Payment)',  'btnText' => 'Make Payment', 'is_new' => true, 'target' => '_blank', 'route' => route('admission_fee_payment')); 

				/* $lists[] = array('lbl_text' => 'पूरक प्रवेश शुल्क ऑनलाइन भुगतान के लिए बटन पर क्लिक करें(Click on the button for Supp. Adm Fee Online Payment)',  'btnText' => 'Make Payment', 'is_new' => true, 'target' => '_blank', 'color' => 'red', 'route' => route('supp_admission_fee_payment')); */

				/* $lists[] = array('lbl_text' => 'Click here to login',  'btnText' => 'Make Payment', 'is_new' => true, 'target' => '_blank', 'color' => 'red', 'route' => route('login')); */

	/*
		 	//$lists[] = array('lbl_text' => 'लॉग इन के लिए कृपया बटन पर क्लिक करें(Please click on the button for Login)',  'btnText' => 'Login', 'is_new' => false,'target' => '_blank', 'route' => route('login')); 
			*/
			
			/*if($showStatus == true && $resultCheckStatus == 2 || $resultCheckStatus==1){
				$lists[] = array('lbl_text' =>' राजस्थान  स्टेट ओपन स्कूल द्वारा  ' .$result_session .' का परिणाम प्रकाशित किया गया है, कृपया! परिणाम देखने  के लिए  "View Result" बटन पर क्लिक करें। ( '.$result_session.' Result has been published by Rajasthan State Open School, Please Click on the "View Result" button to view result. )',  'btnText' => 'View Result', 'is_new' => true, 'route' => route('result')); 
				
			}*/

			/*if($showrevisedStatus == true && $resultCheckStatus == 2 || $resultCheckStatus==1){
				// $lists[] = array('lbl_text' =>' राजस्थान  स्टेट ओपन स्कूल द्वारा  ' .$result_session .' का संशोधित परिणाम प्रकाशित किया गया है, कृपया! संशोधित परिणाम देखने  के लिए  "View Revised Result" बटन पर क्लिक करें। ( '.$result_session.' Revised Result has been published by Rajasthan State Open School, Please Click on the "View Revised Result" button to view result. )',  'btnText' => 'View Revised Result', 'is_new' => true, 'route' => route('revisedresult')); 
				
			}*/
			if($showrevisedStatus == true && $resultCheckStatus == 2 || $resultCheckStatus==1){
				 $lists[] = array('lbl_text' =>' राजस्थान स्टेट ओपन स्कूल द्वारा घोषित पिछले वर्षों के परिणाम देखने के लिए कृपया "View Previous Year Result" बटन पर क्लिक करें।(Please click on "View Previous Year Result" button to view result of previous years result announced by Rajasthan State Open School.)',  'btnText' => 'View Previous Year Result', 'is_new' => true, 'route' => route('resultprevious')); 
				
			}

			
		
		?>
	
   		<div class="collection waves-color-demo"> 
			@foreach(@$lists as $k => $item)
				<div class="collection-item" style="height: 130px !important;">
					<span style="font-size: 18px !important;">
						<span class="language-markup" style="color: blue">
							{{ @$k+1 }}.    
							@if(@$item['color'])
								<span style="color:{{ $item['color'] }}">
									{{ @$item['lbl_text'] }}
								</span>
							@else
								{{ @$item['lbl_text'] }}
							@endif
						</span>
					</span>
					@if(@$item['is_new'])
						<img class="" src="{{asset('public/app-assets/images/new.jpg')}}" height="20" alt="materialize logo"/>
					@endif

					<a href="{{ @$item['route'] }}" target="{{  @$item['target'] }}" class="waves-effect waves-teal btn gradient-45deg-deep-orange-orange white-text secondary-content">
						{{ @$item['btnText'] }}
					</a>
				</div>  
			@endforeach
			
			@php  
				$ssoid = @Auth::user('ssoid');
				@endphp
				@if(@$ssoid)
					<ul>
						<li><a class="grey-text text-darken-1" href="javascript:void(none);"><i class="material-icons">person2</i>{{ @$ssoid->ssoid }}</a></li>
						<li class="divider"></li>
						<li><a class="grey-text text-darken-1" href="{{ route('logout') }}"><i class="material-icons">keyboard_tab</i>Logout</a></li>
					</ul>
				@endif
			</div>
			  
		</p> 
    </div>
  </div>
  </div>

@endsection 
@section('customjs')
	 
@endsection 


<style>
	#main {
		padding-left: 0px !important;
	} 
</style>

