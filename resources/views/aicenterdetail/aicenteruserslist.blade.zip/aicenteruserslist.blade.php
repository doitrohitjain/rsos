@extends('layouts.default')
@section('content')
@if(!empty(@$id = Auth::user()->id))
	<div id="main">
		<div class="row">
		@endif
        <!-- <div id="breadcrumbs-wrapper" data-image="{{ asset('public/app-assets/images/gallery/breadcrumb-bg.jpg')}}">
			Search for small screen
			 <div class="container">
				<div class="row">
					<div class="col s12 m6 l6">
						<h5 class="breadcrumbs-title mt-0 mb-0"><span>{{ $title }}</span></h5>
					</div>
					<div class="col s12 m6 l6 right-align-md">
						<ol class="breadcrumbs mb-0"> 
							@foreach($breadcrumbs as $v)
								<li class="breadcrumb-item"><a href="{{ $v['url'] }}">{{ $v['label'] }}</a></li>
							@endforeach 
						</ol>
					</div>
				</div>
			</div> 
        </div> -->
		
        {{-- removed col s12 --}}
		<div class="">
			<div class="container"> 
				<div class="section section-data-tables"> 
				<div class="row">
				<div class="col s12">
					<div class="card">
					<div class="card-content">
					
					 <h6><a href="{{route('landing')}}" class="btn btn-xs btn-info right mb-2 mr-1">Back to Home</a></h6>
					  
					<h6><b>{{ @$title }}</b><h6>
					</div>
				</div>
				</div>
				
				<div class="row">
					<div class="col s12">
						<div class="card3">
							<div class="card-content3">
								@include('elements.aicenter_listing_notifications')
							</div>
						</div>
					</div>
				</div>
				<div class="col s12">
					<div class="card">
						<div class="card-content">
							@include('elements.filters.search_filter')
						</div>
					</div>
				</div>
				
				
	
				<div class="section section-data-tables"> 
					<div class="row">
						<div class="col s12">
							<div class="card">
								<div class="card-content">
									<div class="row"> 
									<table class="responsive-table">
										<thead>
											<tr>
												<th style="width:5%;">SR.NO</th>
												<th style="width:5%;">Ai Code</th> 
												<th style="width:35%;">AI Centres Name</th>
												<th style="width:5%;">District</th>
												<th style="width:5%;">Block</th>
												<th style="width:10%;">Nodal Officer Name</th>
												<th style="width:13%;">Nodal  Officer Mobile Number</th> 
											</tr>
										</thead>
									<tbody>
										@php $i = 1;@endphp
										@foreach ($data as $key => $user)
											<tr>
												<td style="width:5%;">{{ @$i++ }}</td>
												<td style="width:10%;"> {{ @$user->ai_code }}</td>
												<td style="width:35%;"> {{ @$user->college_name }}</td>
												<td style="width:10%;">{{ @$district_list[$user->district_id] }}</td>
												<td style="width:10%;">{{ @$master_block_list[$user->block_id] }}</td>
												<td style="width:10%;" >{{ @$user->nodal_officer_name }}</td>
												<td style="width:10%;" >{{ @$user->nodal_officer_mobile_number }}</td> 
											</tr>
										@endforeach  
									</tbody> 
									</table>
									{{ $data->withQueryString()->links('elements.paginater') }}
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
        </div>
		</div>
		@if(!empty(@$id = Auth::user()->id))
    </div>
</div> 
		@endif
@endsection 
@section('customjs')
	<script src="{!! asset('public/app-assets/js/bladejs/aicenteruserlist.js') !!}"></script> 
@endsection 
@section('customjs')
<script>
$('.delete-confirm').on('click', function (event) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Are you sure?',
        text: 'This record and it`s details will be deleted!',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$('.lock-confirm').on('click', function (event) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Are you sure?',
        text: 'AI CENTER INACTIVE',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$('.lock-confirms').on('click', function (event) {
    event.preventDefault();
    const url = $(this).attr('href');
    swal({
        title: 'Are you sure?',
        text: 'AI CENTER ACTIVE',
        icon: 'warning',
        buttons: ["Cancel", "Yes!"],
    }).then(function(value) {
        if (value) {
            window.location.href = url;
        }
    });
});
$(document).ready(function(){
 // Add Class
 $('.edit').click(function(){
  $(this).addClass('editMode');
 });

 // Save data
 $(".edit").focusout(function(){
  $(this).removeClass("editMode");
  var id = this.id;
  var split_id = id.split("_");
  var value = $(this).text();
  var name = $(this).attr("name");
  $.ajax({
   type: 'post',
   url:"{{ route('livetableupdate') }}",
   headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
   data: { id:id, value:value, name:name },
   success:function(response){
     if(response == 1){
		swal({
		title: 'Record successfully updated',
		icon: 'success',
		 showConfirmButton: false,
		timer: 1200
		})
     }else{
        console.log("Not saved.");
     }
   }
  });
 
 });

});
</script>
<style>
a[title]:hover::after {
  content: attr(title);
  position: absolute;
  top: -100%;
  left: 80px;
  font_size:25px;
}
.edit{
 width: 100%;
 height: 30px;
}
.editMode{
 border: 2px solid black;
}

</style>
@endsection 



